import time
import random

def generate_code():
    return random.randint(100000, 999999)

def get_current_code():
    epoch_time = int(time.time())
    interval = epoch_time // 30
    random.seed(interval)  # Seed the random number generator
    return generate_code()

if __name__ == "__main__":
    while True:
        print("Current Code:", get_current_code())
        time.sleep(30)
