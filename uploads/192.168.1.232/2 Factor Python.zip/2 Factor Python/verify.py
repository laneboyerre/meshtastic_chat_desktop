from flask import Flask, request, jsonify
from flask_httpauth import HTTPBasicAuth
import time
import random
import logging

app = Flask(__name__)
auth = HTTPBasicAuth()

# Define users and their passwords
users = {
    "user": "pass"  # Replace with your actual username and password
}

@auth.get_password
def get_password(username):
    if username in users:
        return users.get(username)
    return None

def generate_code():
    return random.randint(100000, 999999)

def get_current_code():
    epoch_time = int(time.time())
    interval = epoch_time // 30
    random.seed(interval)  # Seed the random number generator
    return generate_code()

@app.route('/get_code', methods=['GET'])
@auth.login_required
def get_code():
    current_code = get_current_code()
    return jsonify({'code': current_code})

@app.route('/verify_code', methods=['POST'])
@auth.login_required
def verify_code():
    data = request.get_json()
    provided_code = str(data.get('code'))
    if not provided_code:
        logging.error("Code not provided")
        return jsonify({'error': 'Code not provided'}), 400

    current_code = str(get_current_code())
    logging.debug(f"Provided code: {provided_code}, Current code: {current_code}")
    
    if provided_code == current_code:
        logging.info("Verification success")
        return jsonify({'status': 'success'}), 200
    else:
        logging.warning(f"Verification failed. Provided: {provided_code}, Expected: {current_code}")
        return jsonify({'status': 'failure'}), 403

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    app.run(host='0.0.0.0', debug=True, port=5001)
