from flask import Flask, jsonify, request
import time
import random

app = Flask(__name__)

def generate_code():
    return random.randint(100000, 999999)

def get_current_code():
    epoch_time = int(time.time())
    interval = epoch_time // 30
    random.seed(interval)  # Seed the random number generator
    return generate_code()

@app.route('/get_code', methods=['GET'])
def get_code():
    auth = request.authorization
    if not auth or auth.username != 'user' or auth.password != 'pass':
        return jsonify({'error': 'Unauthorized access'}), 401
    current_code = get_current_code()
    return jsonify({'code': current_code})

if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True, port=5007)
